const express = require("express");
const cors = require("cors");
const axios = require("axios");
const nodemailer = require("nodemailer");
const http = require("http");
const { Server } = require("socket.io");


const PORT = Number(process.env.PORT || 5000);
const CLIENT_ORIGIN = process.env.CLIENT_ORIGIN || "*";
const ALERT_COOLDOWN_MS = Number(process.env.ALERT_COOLDOWN_MS || 15 * 60 * 1000);
const MAX_LOGS = Number(process.env.MAX_LOGS || 250);
const HISTORY_WINDOW = Number(process.env.HISTORY_WINDOW || 8);
const ALERT_SCORE = Number(process.env.ALERT_SCORE || 0.58);
const BLOCK_SCORE = Number(process.env.BLOCK_SCORE || 0.78);
const RAPID_RETRY_MS = Number(process.env.RAPID_RETRY_MS || 4 * 1000);
const BURST_WINDOW_MS = Number(process.env.BURST_WINDOW_MS || 60 * 1000);
const PATTERN_WINDOW_MS = Number(process.env.PATTERN_WINDOW_MS || 10 * 60 * 1000);
const SESSION_COOLDOWN_MS = Number(process.env.SESSION_COOLDOWN_MS || 20 * 60 * 1000);
const USER_ATTACK_WINDOW_MS = Number(process.env.USER_ATTACK_WINDOW_MS || 12 * 60 * 1000);
const USER_ATTACK_LOCK_MS = Number(process.env.USER_ATTACK_LOCK_MS || 15 * 60 * 1000);
const USER_BURST_WINDOW_MS = Number(process.env.USER_BURST_WINDOW_MS || 2 * 60 * 1000);

const SAMPLE_GEOS = [
  { location: "Ashburn, United States", lat: 39.0438, lon: -77.4874 },
  { location: "Frankfurt, Germany", lat: 50.1109, lon: 8.6821 },
  { location: "Singapore, Singapore", lat: 1.3521, lon: 103.8198 },
  { location: "Mumbai, India", lat: 19.076, lon: 72.8777 },
  { location: "Sao Paulo, Brazil", lat: -23.5505, lon: -46.6333 }
];

const VPN_PROVIDER_KEYWORDS = [
  "vpn",
  "proxy",
  "tor",
  "digitalocean",
  "amazon",
  "aws",
  "google cloud",
  "microsoft",
  "azure",
  "linode",
  "vultr",
  "ovh",
  "hetzner",
  "oracle cloud",
  "leaseweb",
  "choopa",
  "m247"
];

const app = express();
app.set("trust proxy", true);
app.use(express.json({ limit: "32kb" }));
app.use(cors({ origin: CLIENT_ORIGIN === "*" ? true : CLIENT_ORIGIN }));

const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: CLIENT_ORIGIN === "*" ? true : CLIENT_ORIGIN }
});

const ipState = new Map();
const userSecurity = new Map();
const logs = [];

// ── User store ────────────────────────────────────────────────────────────────
const users = new Map([
  ["admin", {
    username: "admin",
    password: "admin",
    role: "admin",
    email: "admin@gmail.com"
  }]
]);

const emailConfig = {
  user: process.env.ALERT_EMAIL_USER,
  pass: process.env.ALERT_EMAIL_PASS,
  to: process.env.ALERT_EMAIL_TO || process.env.ALERT_EMAIL_USER
};

const transporter = emailConfig.user && emailConfig.pass
  ? nodemailer.createTransport({
      service: "gmail",
      auth: { user: emailConfig.user, pass: emailConfig.pass }
    })
  : null;

// ── IP helpers ────────────────────────────────────────────────────────────────
function getIpRecord(ip) {
  if (!ipState.has(ip)) {
    ipState.set(ip, {
      attempts: 0,
      history: [],
      failureTimes: [],
      lastFailureAt: null,
      lastSuccessAt: null,
      blockedAt: null,
      lastAlertAt: 0,
      patternScore: 0,
      blockCount: 0,
      lastLocation: "Unknown",
      lastLat: 0,
      lastLon: 0,
      lastVpnSuspected: false,
      // enriched geo
      lastCity: "",
      lastRegion: "",
      lastCountry: "",
      lastCountryCode: "",
      lastTimezone: "",
      lastIsp: "",
      lastOrg: "",
      lastAsn: "",
      lastGeoSource: ""
    });
  }
  return ipState.get(ip);
}

function getUserSecurityRecord(username) {
  if (!userSecurity.has(username)) {
    userSecurity.set(username, {
      mainDeviceId: null,
      mainDeviceLabel: null,
      mainDeviceSetAt: null,
      mainDeviceIp: null,
      failedEvents: [],
      underAttackUntil: 0,
      lastAttackScore: 0
    });
  }
  return userSecurity.get(username);
}

function normalizeIp(rawValue) {
  const firstValue = String(rawValue || "").split(",")[0].trim();
  if (!firstValue) return "unknown";
  if (firstValue.startsWith("::ffff:")) return firstValue.slice(7);
  return firstValue;
}

function normalizeDeviceId(rawValue) {
  const normalized = String(rawValue || "").trim();
  if (!normalized) return "";
  return normalized.slice(0, 160);
}

function getClientIp(req) {
  return normalizeIp(req.headers["x-forwarded-for"] || req.ip || req.socket.remoteAddress);
}

function isPrivateIp(ip) {
  return (
    ip === "unknown" ||
    ip === "::1" ||
    ip === "127.0.0.1" ||
    ip.startsWith("10.") ||
    ip.startsWith("192.168.") ||
    /^172\.(1[6-9]|2\d|3[0-1])\./.test(ip)
  );
}

function formatLocation(city, country) {
  const parts = [city, country].filter(Boolean);
  return parts.length ? parts.join(", ") : "Unknown";
}

// ── Email ─────────────────────────────────────────────────────────────────────
async function sendEmail(userEmail, ip, attempts, risk) {
  if (!transporter) return;

  await transporter.sendMail({
    from: emailConfig.user,
    to: userEmail,
    subject: "⚠️ Security Alert",
    html: `
      <h3>Suspicious Login Attempt</h3>
      <p>IP: ${ip}</p>
      <p>Attempts: ${attempts}</p>
      <p>Risk: ${risk}</p>
    `
  });
}

// ── Geo ───────────────────────────────────────────────────────────────────────
// ── Geo enrichment ─────────────────────────────────────────────────────────────
// Primary : ip-api.com  (free, no key, 45 fields, 45 req/min)
// Fallback: ipwho.is    (free, no key, generous limits)
// Both return the exit-node location of VPN/proxy IPs — exactly what we want.
// We never attempt to pierce the VPN tunnel; we just describe where it exits.

function _buildVpnSuspected(data, providerText) {
  return Boolean(
    data.proxy || data.hosting ||
    VPN_PROVIDER_KEYWORDS.some((kw) => providerText.includes(kw))
  );
}

function _formatGeoDetail({ city, regionName, country, isp, org, timezone }) {
  // Build a rich label: "Frankfurt, Hesse, Germany · Hetzner Online GmbH · Europe/Berlin"
  const place  = [city, regionName, country].filter(Boolean).join(", ") || "Unknown";
  const provider = (isp && org && isp !== org) ? `${isp} / ${org}` : (isp || org || "");
  const tz     = timezone || "";
  return [place, provider, tz].filter(Boolean).join(" · ");
}

async function _geoFromIpApi(ip) {
  const fields = "status,message,country,countryCode,region,regionName,city,zip,lat,lon,timezone,isp,org,as,proxy,hosting";
  const res = await axios.get(`http://ip-api.com/json/${ip}?fields=${fields}`, { timeout: 3000 });
  const d = res.data;

  if (d.status !== "success") throw new Error(d.message || "ip-api lookup failed");

  const providerText = [d.isp, d.org, d.as].filter(Boolean).join(" ").toLowerCase();

  return {
    location:     _formatGeoDetail({ city: d.city, regionName: d.regionName, country: d.country, isp: d.isp, org: d.org, timezone: d.timezone }),
    city:         d.city         || "",
    region:       d.regionName   || "",
    country:      d.country      || "",
    countryCode:  d.countryCode  || "",
    timezone:     d.timezone     || "",
    isp:          d.isp          || "",
    org:          d.org          || "",
    asn:          d.as           || "",
    zip:          d.zip          || "",
    lat:          Number(d.lat   || 0),
    lon:          Number(d.lon   || 0),
    vpnSuspected: _buildVpnSuspected(d, providerText),
    source:       "ip-api"
  };
}

async function _geoFromIpWho(ip) {
  const res = await axios.get(`https://ipwho.is/${ip}`, { timeout: 3000 });
  const d = res.data;

  if (!d.success) throw new Error(d.message || "ipwho.is lookup failed");

  const providerText = [d.connection?.isp, d.connection?.org, d.connection?.asn]
    .filter(Boolean).join(" ").toLowerCase();

  return {
    location:     _formatGeoDetail({ city: d.city, regionName: d.region, country: d.country, isp: d.connection?.isp, org: d.connection?.org, timezone: d.timezone?.id }),
    city:         d.city              || "",
    region:       d.region            || "",
    country:      d.country           || "",
    countryCode:  d.country_code      || "",
    timezone:     d.timezone?.id      || "",
    isp:          d.connection?.isp   || "",
    org:          d.connection?.org   || "",
    asn:          String(d.connection?.asn || ""),
    zip:          d.postal            || "",
    lat:          Number(d.latitude   || 0),
    lon:          Number(d.longitude  || 0),
    vpnSuspected: _buildVpnSuspected({ proxy: d.type === "proxy" || d.type === "tor", hosting: d.type === "hosting" }, providerText),
    source:       "ipwho"
  };
}

async function getLocation(ip) {
  if (isPrivateIp(ip)) {
    return {
      location: "Local / Private network",
      city: "", region: "", country: "", countryCode: "",
      timezone: "", isp: "", org: "", asn: "", zip: "",
      lat: 0, lon: 0, vpnSuspected: false, source: "private"
    };
  }

  // Try primary, fall back to secondary
  try { return await _geoFromIpApi(ip); } catch { /* fall through */ }
  try { return await _geoFromIpWho(ip); } catch { /* fall through */ }

  return {
    location: "Unknown",
    city: "", region: "", country: "", countryCode: "",
    timezone: "", isp: "", org: "", asn: "", zip: "",
    lat: 0, lon: 0, vpnSuspected: false, source: "none"
  };
}

/** Write all geo fields from a getLocation() result onto an ipState record. */
function stampGeo(record, geo) {
  record.lastLocation    = geo.location;
  record.lastLat         = geo.lat;
  record.lastLon         = geo.lon;
  record.lastVpnSuspected = geo.vpnSuspected;
  record.lastCity        = geo.city        || "";
  record.lastRegion      = geo.region      || "";
  record.lastCountry     = geo.country     || "";
  record.lastCountryCode = geo.countryCode || "";
  record.lastTimezone    = geo.timezone    || "";
  record.lastIsp         = geo.isp         || "";
  record.lastOrg         = geo.org         || "";
  record.lastAsn         = geo.asn         || "";
  record.lastGeoSource   = geo.source      || "";
}


function clamp(value, min = 0, max = 1) {
  return Math.min(Math.max(value, min), max);
}

function rememberSequence(record) {
  if (!record.attempts) return;
  record.history.push(record.attempts);
  if (record.history.length > HISTORY_WINDOW) record.history.shift();
}

function clearFailureState(record, keepHistory = true) {
  if (keepHistory) rememberSequence(record);
  record.attempts = 0;
  record.failureTimes = [];
  record.patternScore = 0;
}

function trimFailureTimes(record, now) {
  record.failureTimes = record.failureTimes.filter((timestamp) => now - timestamp <= PATTERN_WINDOW_MS);
}

function evaluatePatternModel(record, now) {
  trimFailureTimes(record, now);

  const timestamps = record.failureTimes;
  const baseline = record.history.length
    ? record.history.reduce((sum, value) => sum + value, 0) / record.history.length
    : 1.5;

  const burstFailures = timestamps.filter((timestamp) => now - timestamp <= BURST_WINDOW_MS).length;
  const recentGapMs = timestamps.length > 1 ? now - timestamps[timestamps.length - 2] : Number.POSITIVE_INFINITY;

  let rapidRetries = 0;
  for (let index = 1; index < timestamps.length; index += 1) {
    if (timestamps[index] - timestamps[index - 1] <= RAPID_RETRY_MS) {
      rapidRetries += 1;
    }
  }

  const streakPressure = clamp((record.attempts / Math.max(2, baseline * 1.4) - 0.7) / 1.1);
  const burstPressure = clamp((burstFailures / Math.max(2, Math.ceil(baseline)) - 0.9) / 1.2);
  const retryPressure = clamp((rapidRetries / Math.max(1, timestamps.length - 1) - 0.25) / 0.75);
  const spacingPressure = Number.isFinite(recentGapMs)
    ? clamp((RAPID_RETRY_MS - recentGapMs) / RAPID_RETRY_MS)
    : 0;
  const repeatOffenderPressure = clamp(record.blockCount / 3);

  const score = clamp(
    (streakPressure * 0.34) +
    (burstPressure * 0.28) +
    (retryPressure * 0.18) +
    (spacingPressure * 0.1) +
    (repeatOffenderPressure * 0.1)
  );

  const adaptiveAlertScore = clamp(ALERT_SCORE - (burstPressure * 0.06) - (repeatOffenderPressure * 0.04), 0.42, 0.8);
  const adaptiveBlockScore = clamp(BLOCK_SCORE - (burstPressure * 0.08) - (repeatOffenderPressure * 0.1), 0.58, 0.92);
  const anomalous = score >= adaptiveAlertScore || burstPressure >= 0.85 || retryPressure >= 0.9;

  return {
    anomalous,
    baseline,
    burstFailures,
    rapidRetries,
    recentGapMs,
    score,
    alertScore: adaptiveAlertScore,
    blockScore: adaptiveBlockScore
  };
}

function riskLevel(score, blocked) {
  if (blocked || score >= 0.9) return "Critical";
  if (score >= 0.72) return "High";
  if (score >= 0.52) return "Medium";
  return "Low";
}

function buildReason(ip, attempts, behavior, blocked) {
  if (blocked) return `Pattern model blocked IP ${ip} because its failure rhythm looked unusually weird for this source and escalated too quickly.`;
  if (behavior.anomalous) return "Pattern model flagged this source because retries became unusually bursty versus its normal baseline.";
  if (attempts > 1) return "Repeated failures are being watched, but the pattern is not abnormal enough to auto-block yet.";
  return "Single failure observed; watching for unusual follow-up behavior.";
}

function trimUserFailures(security, now) {
  security.failedEvents = security.failedEvents.filter((event) => now - event.timestamp <= USER_ATTACK_WINDOW_MS);
}

function evaluateUserAttack(security, now) {
  trimUserFailures(security, now);

  const failures = security.failedEvents.length;
  const recentBurst = security.failedEvents.filter((event) => now - event.timestamp <= USER_BURST_WINDOW_MS).length;
  const distinctIps = new Set(security.failedEvents.map((event) => event.ip)).size;
  const distinctDevices = new Set(security.failedEvents.map((event) => event.deviceId).filter(Boolean)).size;

  const score = clamp(
    (Math.min(failures, 8) / 8) * 0.45 +
    (Math.min(recentBurst, 5) / 5) * 0.25 +
    (Math.min(distinctIps, 4) / 4) * 0.2 +
    (Math.min(distinctDevices, 3) / 3) * 0.1
  );

  return { score, failures, recentBurst, distinctIps, distinctDevices };
}

function noteUserFailure(username, ip, deviceId, now) {
  const security = getUserSecurityRecord(username);
  security.failedEvents.push({ timestamp: now, ip, deviceId });
  const attack = evaluateUserAttack(security, now);
  security.lastAttackScore = attack.score;

  const shouldProtect = attack.score >= 0.72 ||
    (attack.failures >= 5 && attack.recentBurst >= 4) ||
    (attack.failures >= 4 && attack.distinctIps >= 2);

  if (shouldProtect) {
    security.underAttackUntil = Math.max(security.underAttackUntil, now + USER_ATTACK_LOCK_MS);
  }

  return attack;
}

function isUserUnderAttack(security, now) {
  return Boolean(security && security.underAttackUntil && security.underAttackUntil > now);
}

function buildProtectedModeReason(username, security) {
  if (!security.mainDeviceId) {
    return `User "${username}" is under heavy attack. All logins are temporarily locked until a main device is registered or the protection window ends.`;
  }
  return `User "${username}" is under heavy attack. Only the registered main device is allowed to sign in until protection mode expires.`;
}

// ── Log helpers ───────────────────────────────────────────────────────────────
function pushLog(entry) {
  logs.unshift(entry);
  if (logs.length > MAX_LOGS) logs.length = MAX_LOGS;
}

function getStats() {
  const blockedIps = Array.from(ipState.values()).filter((r) => r.blockedAt).length;
  const now = Date.now();
  const recentWindowMs = 60 * 60 * 1000;
  return {
    blockedIps,
    trackedIps: ipState.size,
    totalEvents: logs.length,
    recentEvents: logs.filter((l) => now - l.timestamp <= recentWindowMs).length,
    criticalEvents: logs.filter((l) => l.risk === "Critical").length,
    highRiskEvents: logs.filter((l) => l.risk === "High" || l.risk === "Critical").length,
    alertsEnabled: Boolean(transporter),
    totalUsers: users.size
  };
}

function getBlockedIps() {
  return Array.from(ipState.entries())
    .filter(([, record]) => record.blockedAt)
    .sort((a, b) => b[1].blockedAt - a[1].blockedAt)
    .map(([ip, record]) => ({
      ip,
      attempts:      record.attempts,
      blockedAt:     record.blockedAt,
      lastFailureAt: record.lastFailureAt,
      lastSuccessAt: record.lastSuccessAt,
      location:      record.lastLocation  || "Unknown",
      city:          record.lastCity      || "",
      region:        record.lastRegion    || "",
      country:       record.lastCountry   || "",
      countryCode:   record.lastCountryCode || "",
      timezone:      record.lastTimezone  || "",
      isp:           record.lastIsp       || "",
      org:           record.lastOrg       || "",
      asn:           record.lastAsn       || "",
      lat:           Number(record.lastLat || 0),
      lon:           Number(record.lastLon || 0),
      vpnSuspected:  Boolean(record.lastVpnSuspected),
      geoSource:     record.lastGeoSource || ""
    }));
}

function emitStats() {
  io.emit("stats", getStats());
}

function validateCredentials(username, password) {
  return typeof username === "string" && typeof password === "string";
}

// ── Routes ────────────────────────────────────────────────────────────────────
app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "ai-soc", timestamp: new Date().toISOString() });
});

app.get("/stats", (_req, res) => res.json(getStats()));
app.get("/blocked-ips", (_req, res) => res.json(getBlockedIps()));

// Create user
app.post("/users", (req, res) => {
  const { username, password, role, email } = req.body || {};

  if (!email || typeof email !== "string") {
    return res.status(400).json({ error: "Email required" });
  }

  if (!username || !password || typeof username !== "string" || typeof password !== "string") {
    return res.status(400).json({ error: "username and password are required strings." });
  }

  const key = username.trim().toLowerCase();

  if (key.length < 2) {
    return res.status(400).json({ error: "Username must be at least 2 characters." });
  }

  if (password.length < 3) {
    return res.status(400).json({ error: "Password must be at least 3 characters." });
  }

  if (users.has(key)) {
    return res.status(409).json({ error: `User "${key}" already exists.` });
  }

  const entry = {
    username: key,
    password,
    role: role === "admin" ? "admin" : "user",
    email,
    createdAt: Date.now()
  };

  users.set(key, entry);
  emitStats();

  return res.status(201).json({
    success: true,
    username: key,
    role: entry.role,
    createdAt: entry.createdAt
  });
});

// List users (passwords omitted)
app.get("/users", (_req, res) => {
  const list = Array.from(users.values()).map(({ username, role, email, createdAt }) => {
    const security = getUserSecurityRecord(username);
    return {
      username,
      role,
      email,
      createdAt,
      mainDeviceConfigured: Boolean(security.mainDeviceId),
      mainDeviceIp: security.mainDeviceIp || null,
      protectedMode: isUserUnderAttack(security, Date.now())
    };
  });
  res.json(list);
});

// Delete user
app.delete("/users/:username", (req, res) => {
  const key = req.params.username.trim().toLowerCase();

  if (key === "admin") {
    return res.status(403).json({ error: "Cannot delete the built-in admin account." });
  }

  if (!users.has(key)) {
    return res.status(404).json({ error: `User "${key}" not found.` });
  }

  users.delete(key);
  userSecurity.delete(key);
  emitStats();
  return res.json({ success: true, deleted: key });
});

app.post("/users/:username/main-device", (req, res) => {
  const key = req.params.username.trim().toLowerCase();
  const { password, deviceId, deviceLabel } = req.body || {};
  const user = users.get(key);

  if (!user) {
    return res.status(404).json({ error: `User "${key}" not found.` });
  }

  if (typeof password !== "string" || user.password !== password) {
    return res.status(403).json({ error: "Valid account password required to register a main device." });
  }

  const normalizedDeviceId = normalizeDeviceId(deviceId);
  if (!normalizedDeviceId) {
    return res.status(400).json({ error: "A device identifier is required." });
  }

  const security = getUserSecurityRecord(key);
  if (security.mainDeviceId && security.mainDeviceId !== normalizedDeviceId) {
    return res.status(423).json({ error: "Main device changes must be made from the current registered main device." });
  }

  if (isUserUnderAttack(security, Date.now()) && !security.mainDeviceId) {
    return res.status(423).json({ error: "This user is already in protection mode. Wait for the attack window to end before registering a first main device." });
  }

  security.mainDeviceId = normalizedDeviceId;
  security.mainDeviceLabel = String(deviceLabel || "Current browser").slice(0, 120);
  security.mainDeviceSetAt = Date.now();
  security.mainDeviceIp = getClientIp(req);

  return res.json({
    success: true,
    username: key,
    mainDeviceConfigured: true,
    mainDeviceIp: security.mainDeviceIp,
    deviceLabel: security.mainDeviceLabel,
    mainDeviceSetAt: security.mainDeviceSetAt
  });
});

app.post("/blocked-ips/:ip/unblock", (req, res) => {
  const ip = normalizeIp(decodeURIComponent(req.params.ip));
  const record = ipState.get(ip);

  if (!record || !record.blockedAt) {
    return res.status(404).json({ error: `IP "${ip}" is not currently blocked.` });
  }

  clearFailureState(record, false);
  record.history = [];
  record.blockedAt = null;
  record.lastFailureAt = null;
  record.lastAlertAt = 0;

  const log = {
    ip,
    location: "Manual admin action",
    lat: 0,
    lon: 0,
    vpnSuspected: Boolean(record.lastVpnSuspected),
    attempts: 0,
    risk: "Low",
    anomaly: "Normal",
    action: "Unblocked",
    reason: `IP ${ip} was manually unblocked from the admin dashboard.`,
    source: "admin",
    timestamp: Date.now()
  };

  pushLog(log);
  io.emit("attack", log);
  io.emit("blocked-ips", getBlockedIps());
  emitStats();

  return res.json({ success: true, ip });
});

// Login
app.post("/login", async (req, res) => {
  const { username, password, deviceId, deviceLabel } = req.body || {};

  const ip = getClientIp(req);
  const record = getIpRecord(ip);

  if (!validateCredentials(username, password)) {
    return res.status(400).json({ success: false, error: "Username and password must both be strings." });
  }

  const key = String(username).trim().toLowerCase();
  const user = users.get(key);
  const normalizedDeviceId = normalizeDeviceId(deviceId);
  const security = getUserSecurityRecord(key);
  const isValid = user && user.password === password;  // ✅ declared before use
  const now = Date.now();
  const protectedMode = isUserUnderAttack(security, now);

  if (record.blockedAt) {
    return res.status(429).json({
      success: false,
      attempts: record.attempts,
      risk: "Critical",
      anomaly: "Anomalous",
      blocked: true,
      vpnSuspected: Boolean(record.lastVpnSuspected),
      protectedMode,
      mainDeviceConfigured: Boolean(security.mainDeviceId),
      mainDeviceMatched: Boolean(security.mainDeviceId && normalizedDeviceId && security.mainDeviceId === normalizedDeviceId),
      reason: "Pattern model already marked this IP as blocked because its failure behavior looked unusually aggressive."
    });
  }

  if (protectedMode) {
    const mainDeviceMatched = Boolean(security.mainDeviceId && normalizedDeviceId && security.mainDeviceId === normalizedDeviceId);
    if (!mainDeviceMatched) {
      return res.status(423).json({
        success: false,
        attempts: record.attempts,
        risk: "Critical",
        anomaly: "Protected",
        blocked: true,
        vpnSuspected: Boolean(record.lastVpnSuspected),
        protectedMode: true,
        mainDeviceConfigured: Boolean(security.mainDeviceId),
        mainDeviceMatched: false,
        reason: buildProtectedModeReason(key, security)
      });
    }
  }

  if (isValid) {
    clearFailureState(record, true);
    record.blockedAt = null;
    record.lastFailureAt = null;
    record.lastSuccessAt = Date.now();
    const mainDeviceMatched = Boolean(security.mainDeviceId && normalizedDeviceId && security.mainDeviceId === normalizedDeviceId);
    if (mainDeviceMatched) {
      security.mainDeviceIp = ip;
    }

    const geo = await getLocation(ip);
    stampGeo(record, geo);
    const log = {
      ip,
      location:     geo.location,
      city:         geo.city,
      region:       geo.region,
      country:      geo.country,
      countryCode:  geo.countryCode,
      timezone:     geo.timezone,
      isp:          geo.isp,
      org:          geo.org,
      asn:          geo.asn,
      lat:          geo.lat,
      lon:          geo.lon,
      vpnSuspected: geo.vpnSuspected,
      geoSource:    geo.source,
      attempts: 0,
      risk: "None",
      anomaly: "Normal",
      action: "Allowed",
      reason: `Successful login as "${key}".`,
      source: "login",
      timestamp: Date.now()
    };

    pushLog(log);
    io.emit("login", log);
    io.emit("blocked-ips", getBlockedIps());
    emitStats();

    return res.json({
      success: true,
      attempts: 0,
      risk: "None",
      anomaly: "Normal",
      blocked: false,
      vpnSuspected: geo.vpnSuspected,
      city:         geo.city,
      region:       geo.region,
      country:      geo.country,
      countryCode:  geo.countryCode,
      timezone:     geo.timezone,
      isp:          geo.isp,
      org:          geo.org,
      asn:          geo.asn,
      geoSource:    geo.source,
      protectedMode,
      mainDeviceConfigured: Boolean(security.mainDeviceId),
      mainDeviceMatched,
      username: key,
      deviceLabel: String(deviceLabel || "Current browser").slice(0, 120),
      reason: `Credentials accepted for "${key}". Monitoring baseline reset.`
    });
  }

  if (record.lastFailureAt && now - record.lastFailureAt > SESSION_COOLDOWN_MS) {
    clearFailureState(record, true);
  }

  record.attempts += 1;
  record.lastFailureAt = now;
  record.failureTimes.push(now);
  noteUserFailure(key, ip, normalizedDeviceId, now);

  const behavior = evaluatePatternModel(record, now);
  record.patternScore = behavior.score;

  const blocked = behavior.score >= behavior.blockScore;
  const risk = riskLevel(behavior.score, blocked);
  const reason = buildReason(ip, record.attempts, behavior, blocked);

  // Send alert: prefer targeted user's email, fall back to admin email or ALERT_EMAIL_TO
  // so attacks on unknown/wrong usernames still trigger an alert.
  if (behavior.score >= behavior.alertScore && now - record.lastAlertAt >= ALERT_COOLDOWN_MS) {
    record.lastAlertAt = now;
    const adminEmail = users.get("admin")?.email;
    const alertEmail = user?.email || emailConfig.to || adminEmail;
    if (alertEmail) {
      sendEmail(alertEmail, ip, record.attempts, risk)
        .catch((e) => console.error("Email alert failed:", e.message));
    } else {
      console.warn("[alert] No recipient email — configure ALERT_EMAIL_TO or ensure admin has an email.");
    }
  }

  const geo = await getLocation(ip);
  stampGeo(record, geo);
  const log = {
    ip,
    location:     geo.location,
    city:         geo.city,
    region:       geo.region,
    country:      geo.country,
    countryCode:  geo.countryCode,
    timezone:     geo.timezone,
    isp:          geo.isp,
    org:          geo.org,
    asn:          geo.asn,
    lat:          geo.lat,
    lon:          geo.lon,
    vpnSuspected: geo.vpnSuspected,
    geoSource:    geo.source,
    attempts: record.attempts,
    risk,
    anomaly: behavior.anomalous ? "Anomalous" : "Normal",
    action: blocked ? "Blocked" : "Observed",
    reason,
    source: "login",
    timestamp: now
  };

  if (blocked) {
    record.blockedAt = now;
    record.blockCount += 1;
  }

  pushLog(log);
  io.emit("attack", log);
  io.emit("blocked-ips", getBlockedIps());
  emitStats();

  return res.json({
    success: false,
    attempts: record.attempts,
    risk,
    anomaly: behavior.anomalous ? "Anomalous" : "Normal",
    blocked,
    vpnSuspected: geo.vpnSuspected,
    city:         geo.city,
    region:       geo.region,
    country:      geo.country,
    countryCode:  geo.countryCode,
    timezone:     geo.timezone,
    isp:          geo.isp,
    org:          geo.org,
    asn:          geo.asn,
    geoSource:    geo.source,
    protectedMode: isUserUnderAttack(security, now),
    mainDeviceConfigured: Boolean(security.mainDeviceId),
    mainDeviceMatched: Boolean(security.mainDeviceId && normalizedDeviceId && security.mainDeviceId === normalizedDeviceId),
    reason
  });
});

app.get("/simulate", async (req, res) => {
  const requestedCount = Number.parseInt(req.query.count, 10);
  const count = Number.isFinite(requestedCount) ? Math.min(Math.max(requestedCount, 1), 20) : 6;
  const created = [];

  for (let index = 0; index < count; index += 1) {
    const ip = `${20 + Math.floor(Math.random() * 180)}.${10 + Math.floor(Math.random() * 200)}.${10 + Math.floor(Math.random() * 200)}.${10 + Math.floor(Math.random() * 200)}`;
    const record = getIpRecord(ip);
    const geo = SAMPLE_GEOS[index % SAMPLE_GEOS.length];
    const now = Date.now() + index;

    record.attempts = 4 + (index % 3);
    record.history = [1, 1, 2, 2 + (index % 2)];
    record.failureTimes = [now - 28000, now - 12000, now - 4500, now - 1200];
    record.patternScore = 0.92;
    record.blockCount += 1;
    record.blockedAt = now;
    record.lastLocation = geo.location;
    record.lastLat = geo.lat;
    record.lastLon = geo.lon;
    record.lastVpnSuspected = false;

    const log = {
      ip,
      location: geo.location,
      lat: geo.lat,
      lon: geo.lon,
      vpnSuspected: false,
      attempts: record.attempts,
      risk: index % 2 === 0 ? "Critical" : "High",
      anomaly: "Anomalous",
      action: "Blocked",
      reason: "Simulated weird retry pattern triggered the adaptive blocker.",
      source: "simulation",
      timestamp: now
    };

    pushLog(log);
    created.push(log);
    io.emit("attack", log);
  }

  io.emit("blocked-ips", getBlockedIps());
  emitStats();
  return res.json({ success: true, created: created.length });
});

app.get("/timeline", (_req, res) => res.json([...logs].sort((a, b) => a.timestamp - b.timestamp)));
app.get("/logs", (_req, res) => res.json(logs));

io.on("connection", (socket) => {
  socket.emit("stats", getStats());
  socket.emit("blocked-ips", getBlockedIps());
});

server.listen(PORT, () => {
  console.log(`AI-SOC server running on ${PORT}`);
});

// ── Threat detection ──────────────────────────────────────────────────────────
function detectThreat(body, ip, record) {
  const payload = JSON.stringify(body).toLowerCase();

  let type = "Normal";
  let severity = "Low";

  if (payload.match(/('|--|;|union|select|drop|insert|delete)/)) {
    type = "SQL Injection";
    severity = "Critical";
  } else if (payload.match(/<script>|javascript:|onerror=|onload=/)) {
    type = "XSS Attack";
    severity = "High";
  } else if (record.patternScore >= 0.72 || record.blockCount > 0) {
    type = "Bot Activity";
    severity = record.patternScore >= 0.9 ? "Critical" : "High";
  }

  return { type, severity };
}

app.post("/scan", (req, res) => {
  const ip = getClientIp(req);
  const record = getIpRecord(ip);
  const threat = detectThreat(req.body, ip, record);

  res.json({
    ip,
    detected: threat.type,
    severity: threat.severity,
    message: threat.type === "Normal" ? "No threat detected" : `Detected ${threat.type}`
  });
});