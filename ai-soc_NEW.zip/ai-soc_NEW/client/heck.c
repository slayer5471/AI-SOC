#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
// int main(){
//     int n;
//     int *arr;
//     printf("enter the number");
//     scanf("%d",&n);
//     arr = (int*)malloc(n*(sizeof(int)));
//     for(int i=0;i<n;i++){
//         printf("%d  , ",arr[i]);

//     }
//     return 0;
// }
// int main(){
//     int* ptr = (int*)calloc(3,sizeof(int));
//     ptr = (int*)realloc(ptr,4*sizeof(int));
//     free(ptr);
//     for(int i = 0;i<4;i++){
//         printf("%d  ,",ptr[i]);

//     }
//     return 0;
// }
// dangling pointer refers to the pointer which doesnot exist 
// this occurs after freeing an array
// struct student {
//     int roll_no;
//     char name[10];
//     int marks;
// };
// int main() {
//     struct student s1 = {101,'mani',90};   initialisation
//     struct student s2 = {102,'hello',100};

// }

// struct student {
//     int roll_no;
//     int marks;
// };

// int main() {
//     // 1. Create an array of structures
//     struct student s[2];

//     // 2. Initialize the array elements
//     s[0].roll_no = 10;
//     s[0].marks = 10;

//     s[1].roll_no = 20;
//     s[1].marks = 20;

//     // 3. Now you can use the loop with the index 'i'
//     for(int i = 0; i < 2; i++) {
//         printf("Roll: %d, Marks: %d\n", s[i].roll_no, s[i].marks);
//     }

//     return 0;
// }

// arrow is used to access the members of a structure through a pointer. It is a shorthand notation for dereferencing the pointer and then accessing the member. For example, if you have a pointer to a structure called 'ptr', you can access its member 'roll_no' using 'ptr->roll_no' instead of '(*ptr).roll_no'.
// typedef is used for defining the type of data and is set as constant
// typedef int marks; // Now 'marks' is a nickname for 'int'

// marks math = 90;
// marks science = 85;
// unions store memory just like a structure, but they can only hold one member at a time. The size of a union is determined by the size of its largest member. When you assign a value to one member of a union, it overwrites the previous value stored in the union. This allows you to save memory when you need to store different types of data but only one type at a time.
// each value you initialise is stored in the same memory location so when you give value to other variable this overwrites the previous one 
// and previous one when accessed wil give garbage value 
// #include <stdio.h>

// union Data {
//     int list[3];      // Array of 3 integers
//     long long large;  // A single large number
// };

// int main() {
//     union Data d;

//     // We can store 3 values inside the union because they are in an array
//     d.list[0] = 10;
//     d.list[1] = 20;
//     d.list[2] = 30;

//     printf("Values in array: %d, %d, %d\n", d.list[0], d.list[1], d.list[2]);
//     printf("Total size of union: %lu bytes\n", sizeof(d));

//     // WARNING: Storing this will overwrite the entire array!
//     d.large = 999999999; 
    
//     return 0;
// }
// #include <stdio.h>

// union Box {
//     int integer;
//     float decimal;
// };

// int main() {
//     union Box b;

//     // 1. Assign a value to the integer member
//     b.integer = 100;
//     printf("Before: b.integer = %d\n", b.integer);

//     // 2. Assign a value to the decimal member
//     // This overwrites the memory used by 'integer'
//     b.decimal = 12.5; 

//     printf("After:  b.decimal = %.1f\n", b.decimal);
    
//     // 3. Try to access the original integer
//     // It's gone! You'll get "garbage" (the bit representation of 12.5)
//     printf("After:  b.integer = %d (Corrupted!)\n", b.integer);

//     return 0;
// }
// enums are used to replace the constant values with the names which are more readable and easy to understand
// Enums are used to make code readable, organized, and less error-prone by replacing numbers with names
// enum Day { MON, TUE, WED };

// switch(day) {
//     case MON:
//         printf("Monday");
//         break;
//     case TUE:
//         printf("Tuesday");
//         break;
// }
// struct bits {
//     unsigned int a : 2;
//     unsigned int b : 3;
// };

// int main() {
//     struct bits x = {2, 4};

//     printf("%d %d", x.a, x.b);
// }
// #include <stdio.h>

// typedef struct bits {
//     unsigned int a : 2;
//     unsigned int b : 3;
// } Bits;

// int main() {
//     Bits x = {2, 5};

//     printf("%d %d", x.a, x.b);
// // }
// int main(){
//     char s1[30],s2[30];
//     strcpy(s1,"computer");
//     strcpy(s2,"hello");
//     if (strcmp(s1,s2) <0){
//        strcat(s1,s2);
//     }
//     else{
//         strcat(s2,s1);
//         s1[strlen(s1)-6] = '\0';
//         printf("%s",s1);
//     }
//     return 0;
// }
// #include<stdio.h>
// int main()
// {
//  char *s= "hello";
//  char *p = s;
//  printf("%c %c", 1[p], s[1]);
// }
// #include <stdio.h>
// #include <string.h>

// typedef struct{
//     char name[20];
//     int hands;
//     int legs;
// } prob;

// int main(){

//     prob list[6];

//     strcpy(list[0].name,"human");
//     list[0].hands = 2;
//     list[0].legs = 2;

//     strcpy(list[1].name,"dog");
//     list[1].hands = 0;
//     list[1].legs = 4;

//     strcpy(list[2].name,"cat");
//     list[2].hands = 0;
//     list[2].legs = 4;

//     strcpy(list[3].name,"bird");
//     list[3].hands = 0;
//     list[3].legs = 2;

//     strcpy(list[4].name,"chair");
//     list[4].hands = 2;
//     list[4].legs = 4;

//     for(int i = 0; i < 5; i++){

//         printf("%s has %d hands and %d legs\n",
//                list[i].name,
//                list[i].hands,
//                list[i].legs);
//     }

//     return 0;
// }
// void func(node* head)
// {
// if(!head)
// {
// return;
// }
// func(head->link);
// printf("%d ",head->data);
// }
// int main()
// {
//  char *str = "hello world";
//  char strc[] = "good morning india\n";
//  strcpy(strc, str);
//  printf("%s\n", strc);
//  return 0;
// }
// int main()
// {
//  char str1[15];
//  char str2[15];
//  int mat;
//  strcpy(str1, "abcdef");
//  strcpy(str2, "ABCDEF");
//  mat= strncmp(str1, str2, 4);
//  if(mat< 0)
//  printf("str1 is not greater than str2");
//  else if(mat> 0)
//  printf("str2 is is not greater than str1");
//  else
//  printf("both are equal");
// }
// #include <stdio.h>

// int main(){

//     int n, demo, digit, total = 0;

//     printf("Enter the number: ");
//     scanf("%d", &n);

//     demo = n;

//     while(demo != 0){

//         digit = demo % 10;

//         total = total + digit * digit * digit;

//         demo = demo / 10;
//     }

//     if(total == n){
//         printf("The number is Armstrong");
//     }
//     else{
//         printf("The number is not Armstrong");
//     }

//     return 0;
// }
// int main(){
//     int a = 10;
//     int b = 20;
//     int temp;
//     temp = a;
//     a = b;
//     b = temp;
//     printf("a = %d, b = %d", a, b);
// }
// #include <stdio.h>

// int main(int argc, char *argv[]) {
//     printf("Number of arguments: %d\n", argc);

//     for (int i = 0; i < argc; i++) {
//         printf("argv[%d] = %s\n", i, argv[i]);
//     }

//     return 0;
// }
// #include<stdio.h>
// #include<string.h>
// int main(int argc,char *argv[])		
// {
// 	printf("count of arguments are %d\n",argc);	
// 	//If you execute this code a.exe 367 4898
// 	// argc =3
// 	printf("argv[0] is %s\n",argv [0]);
// 	printf("argv[1] is %s\n",argv[1]);
// 	printf("argv[2] is %s\n",argv[2]);
// 	printf("argv[3] is %s\n",argv[3]);		// null
	
// }
// #include<stdio.h>
// #include<stdlib.h>
// int main(int argc,char *argv[])		
// {
	
// 	// printf("sum is %d\n",argv[1]+argv[2]);			// compilation error
// 	printf("sum is %d\n",atoi(argv[1])+atoi(argv[2]));		
// 	// The C library function atoi(str) converts the string argument str to an integer 
// 	return 0;
	
	
// }
// #include <stdio.h>
// #include <stdlib.h>
// int main(){
// 	char *p = "12345";
// 	printf("%d", atoi(p));

// }
#include <stdio.h>

int main()
{
    FILE *fp = fopen("abc.txt", "r");

    if(fp == NULL)
    {
        perror("Error opening file");
    }

    return 0;
}