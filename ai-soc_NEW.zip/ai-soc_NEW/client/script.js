const API  = document.body.dataset.api  || "http://localhost:5000";
const PAGE = document.body.dataset.page || "login";

const state = {
  logs: [],
  blockedIps: [],
  replayTimer: null,
  lastLoginContext: null
};

// ── Field-name randomisation (anti-bot) ────────────────────────────────────────
//
// Every page load generates fresh random tokens for the username and password
// field IDs, names, and autocomplete attributes.  Any script that was scraped
// or written against hard-coded selectors like getElementById('username') or
// querySelector('[name=password]') will return null and silently fail.
//
// The tokens rotate again on a short interval while the page is open, so a bot
// that successfully read the DOM once will be broken on the next poll cycle.
//
// Only our own handleLoginSubmit reads the fields — it uses the live token
// references stored in FIELD_TOKENS, so normal users are never affected.

const FIELD_TOKENS = {
  usernameId:   "",
  passwordId:   "",
  rotateHandle: null
};

// Pool of plausible-looking but meaningless segment strings.
const _SEGMENTS = [
  "ctrl","ref","tok","uid","inp","val","fld","key","sec","tag",
  "auth","sig","vec","map","idx","obj","buf","ptr","blk","grp"
];

function _rand(n) { return Math.floor(Math.random() * n); }

function _generateToken() {
  // e.g. "ctrl_3a9f_tok_7b2e"  — looks like a real identifier, means nothing
  const a = _SEGMENTS[_rand(_SEGMENTS.length)];
  const b = Math.random().toString(16).slice(2, 6);
  const c = _SEGMENTS[_rand(_SEGMENTS.length)];
  const d = Math.random().toString(16).slice(2, 6);
  return `${a}_${b}_${c}_${d}`;
}

/**
 * Rename both login fields to brand-new random IDs/names and plant a
 * matching number of invisible decoy inputs to confuse scrapers further.
 */
function rotateFieldTokens() {
  const userLabel = document.getElementById("username-label");
  const passLabel = document.getElementById("password-label");
  if (!userLabel || !passLabel) return;           // not on login page

  const userInput = userLabel.querySelector("input");
  const passInput = passLabel.querySelector("input");
  if (!userInput || !passInput) return;

  // ── 1. Pick fresh tokens ───────────────────────────────────────────────────
  const newUserId  = _generateToken();
  const newPassId  = _generateToken();

  // ── 2. Apply to the real fields ───────────────────────────────────────────
  userInput.id   = newUserId;
  userInput.name = newUserId;
  passInput.id   = newPassId;
  passInput.name = newPassId;

  // ── 3. Store so handleLoginSubmit can find them ────────────────────────────
  FIELD_TOKENS.usernameId = newUserId;
  FIELD_TOKENS.passwordId = newPassId;

  // ── 4. Inject / refresh decoy inputs ──────────────────────────────────────
  //    Remove any previous decoys, then plant new ones with names that
  //    look like the real thing (username / password variants) but are
  //    hidden and hold no real value.
  document.querySelectorAll(".soc-decoy").forEach(el => el.remove());

  const decoyNames = [
    "username","password","user","pass","passwd","uname",
    "login","credential","secret","user_name","user_pass"
  ];
  const form = document.getElementById("login-form");
  if (form) {
    decoyNames.forEach(name => {
      const decoy = document.createElement("input");
      decoy.type      = "text";          // NOT password — easier to detect in DevTools but bots read name
      decoy.name      = name;
      decoy.id        = name;
      decoy.className = "soc-decoy";
      decoy.tabIndex  = -1;
      decoy.setAttribute("aria-hidden", "true");
      decoy.setAttribute("autocomplete", "off");
      // Style: visually gone, not just hidden (hidden inputs get skipped by some bots deliberately)
      decoy.style.cssText = [
        "position:absolute",
        "left:-9999px",
        "width:1px",
        "height:1px",
        "opacity:0",
        "pointer-events:none",
        "overflow:hidden"
      ].join(";");
      form.appendChild(decoy);
    });
  }
}

/** Start continuous rotation while the tab is visible. */
function startFieldRotation() {
  rotateFieldTokens();   // apply immediately on load

  // Rotate every 3 seconds — fast enough to trip up polling bots,
  // slow enough to never interrupt a human mid-typing (form submit
  // reads FIELD_TOKENS at the moment of click, not a stale closure).
  FIELD_TOKENS.rotateHandle = setInterval(rotateFieldTokens, 3000);

  // Pause rotation while the user is actively typing so the id under
  // their cursor doesn't change mid-keystroke (edge-case safety).
  document.addEventListener("focusin",  () => clearInterval(FIELD_TOKENS.rotateHandle));
  document.addEventListener("focusout", () => {
    FIELD_TOKENS.rotateHandle = setInterval(rotateFieldTokens, 3000);
  });
}

// ── Utilities ──────────────────────────────────────────────────────────────────
function byId(id) { return document.getElementById(id); }

function toTitleCase(value) {
  const text = String(value || "");
  return text.charAt(0).toUpperCase() + text.slice(1).toLowerCase();
}

function formatDateTime(timestamp) {
  if (!timestamp) return "—";
  const d = new Date(timestamp);
  if (isNaN(d.getTime())) return "—";
  return d.toLocaleString([], {
    year: "numeric", month: "short", day: "2-digit",
    hour: "2-digit", minute: "2-digit", second: "2-digit"
  });
}

function formatLocationLabel(entry) {
  // Build a rich label from all available geo fields
  const parts = [];

  const place = [entry?.city, entry?.region, entry?.country]
    .filter(Boolean).join(", ");
  if (place) parts.push(place);
  else if (entry?.location && entry.location !== "Unknown") parts.push(entry.location);
  else parts.push("Unknown location");

  if (entry?.isp || entry?.org) {
    const provider = (entry.isp && entry.org && entry.isp !== entry.org)
      ? `${entry.isp} / ${entry.org}`
      : (entry.isp || entry.org);
    parts.push(provider);
  }

  if (entry?.timezone) parts.push(entry.timezone);
  if (entry?.asn)      parts.push(entry.asn);

  const label = parts.join(" · ");
  return entry?.vpnSuspected ? `${label} ⚠ VPN/Proxy` : label;
}

function getStoredDeviceId() {
  const storageKey = "ai_soc_device_id";
  let deviceId = "";
  try {
    deviceId = localStorage.getItem(storageKey) || "";
    if (!deviceId) {
      deviceId = typeof crypto?.randomUUID === "function"
        ? crypto.randomUUID()
        : `device-${Date.now()}-${Math.random().toString(16).slice(2)}`;
      localStorage.setItem(storageKey, deviceId);
    }
  } catch {
    deviceId = `device-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  }
  return deviceId;
}

function getDeviceLabel() {
  const agent = navigator.userAgent || "Current browser";
  return agent.slice(0, 120);
}

function clearChildren(node) {
  while (node.firstChild) node.removeChild(node.firstChild);
}

function makeBadge(text, className) {
  const badge = document.createElement("span");
  badge.className = className;
  badge.textContent = text;
  return badge;
}

async function request(path, options = {}) {
  const response = await fetch(`${API}${path}`, options);
  const contentType = response.headers.get("content-type") || "";
  const data = contentType.includes("application/json")
    ? await response.json()
    : await response.text();

  if (!response.ok) {
    const message = typeof data === "string"
      ? data
      : data.error || data.reason || "Request failed.";
    const error = new Error(message);
    error.payload = typeof data === "object" && data !== null ? data : null;
    throw error;
  }

  return data;
}

function setButtonLoading(button, loading, busyText) {
  if (!button) return;
  if (!button.dataset.defaultLabel) {
    button.dataset.defaultLabel = button.textContent;
  }
  button.disabled = loading;
  button.textContent = loading ? busyText : button.dataset.defaultLabel;
}

// ── Login page ─────────────────────────────────────────────────────────────────
function renderLoginResult(result) {
  const resultBox = byId("login-result");
  const status    = byId("login-status");
  const risk      = byId("login-risk");
  const attempts  = byId("login-attempts");
  const anomaly   = byId("login-anomaly");
  const blocked   = byId("login-blocked");
  const reason    = byId("login-reason");
  const deviceNote = byId("device-note");
  const deviceAction = byId("set-main-device-button");

  resultBox.classList.remove("hidden");

  const successful = Boolean(result.success);
  status.textContent = successful ? "Access granted" : "Access denied";
  status.className   = `status-pill ${successful ? "success" : "fail"}`;

  const riskValue = String(result.risk || "Low").toLowerCase();
  risk.textContent = toTitleCase(riskValue);
  risk.className   = `risk-pill ${riskValue}`;

  attempts.textContent = String(result.attempts ?? 0);

  // Build anomaly label — include ISP/org if present so VPN exit info is visible
  let anomalyText = result.anomaly || "Normal";
  if (result.vpnSuspected) anomalyText += " / VPN suspected";
  if (result.isp || result.org) {
    const provider = (result.isp && result.org && result.isp !== result.org)
      ? `${result.isp} / ${result.org}`
      : (result.isp || result.org);
    anomalyText += ` · ${provider}`;
  }
  if (result.timezone) anomalyText += ` · ${result.timezone}`;
  anomaly.textContent = anomalyText;
  blocked.textContent  = result.protectedMode
    ? (result.mainDeviceMatched ? "Protected / Main Device" : "Protected")
    : (result.blocked ? "Blocked" : "Open");
  reason.textContent   = result.vpnSuspected
    ? `${result.reason || "No reason provided."} VPN suspected for this source.`
    : (result.reason || "No reason provided.");

  if (deviceNote) {
    if (successful) {
      if (result.mainDeviceMatched) {
        deviceNote.textContent = "This browser is registered as the main device.";
      } else if (result.mainDeviceConfigured) {
        deviceNote.textContent = "Another browser is currently registered as the main device.";
      } else {
        deviceNote.textContent = "This browser is not registered yet. You can set it as the main device now.";
      }
    } else if (result.protectedMode) {
      deviceNote.textContent = result.mainDeviceConfigured
        ? "Protection mode is active: only the registered main device can sign in."
        : "Protection mode is active, but this user has no main device registered yet.";
    } else {
      deviceNote.textContent = "This browser keeps the same device ID for future trusted-device checks.";
    }
  }

  if (deviceAction) {
    deviceAction.classList.toggle("hidden", !successful);
    if (successful) {
      deviceAction.disabled = Boolean(result.mainDeviceMatched);
      deviceAction.textContent = result.mainDeviceMatched ? "Main Device Active" : "Set This Device As Main";
    }
  }
}

async function handleLoginSubmit(event) {
  event.preventDefault();
  const button = byId("login-button");

  // ── Read values via live token references, NOT hard-coded ids ─────────────
  const userInput = byId(FIELD_TOKENS.usernameId);
  const passInput = byId(FIELD_TOKENS.passwordId);

  const username = userInput ? userInput.value.trim() : "";
  const password = passInput ? passInput.value : "";
  const deviceId = getStoredDeviceId();
  const deviceLabel = getDeviceLabel();

  setButtonLoading(button, true, "Checking...");
  try {
    const result = await request("/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password, deviceId, deviceLabel })
    });
    state.lastLoginContext = { username, password, deviceId, deviceLabel };
    renderLoginResult(result);
  } catch (error) {
    state.lastLoginContext = { username, password, deviceId, deviceLabel };
    renderLoginResult(error.payload || {
      success: false, attempts: 0, risk: "High",
      anomaly: "Unknown", blocked: false, reason: error.message
    });
  } finally {
    setButtonLoading(button, false);
  }
}

async function setCurrentDeviceAsMain() {
  const button = byId("set-main-device-button");
  const deviceNote = byId("device-note");
  const context = state.lastLoginContext;

  if (!context?.username || !context?.password || !context?.deviceId) {
    if (deviceNote) deviceNote.textContent = "Sign in successfully before setting a main device.";
    return;
  }

  setButtonLoading(button, true, "Saving...");
  try {
    const result = await request(`/users/${encodeURIComponent(context.username)}/main-device`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        password: context.password,
        deviceId: context.deviceId,
        deviceLabel: context.deviceLabel
      })
    });

    if (deviceNote) {
      deviceNote.textContent = `Main device saved for "${result.username}". This browser will keep access during protection mode.`;
    }
    button.textContent = "Main Device Active";
    button.disabled = true;
  } catch (error) {
    if (deviceNote) deviceNote.textContent = error.message;
  } finally {
    if (!button.disabled) setButtonLoading(button, false);
  }
}

function initLoginPage() {
  // Rotate field tokens before attaching the submit handler
  startFieldRotation();

  byId("login-form").addEventListener("submit", handleLoginSubmit);
  byId("set-main-device-button").addEventListener("click", () => {
    setCurrentDeviceAsMain().catch(() => {});
  });

  const deviceNote = byId("device-note");
  if (deviceNote) {
    deviceNote.textContent = `Current browser device ID ready: ${getStoredDeviceId().slice(0, 12)}...`;
  }
}

// ── Admin — stats ──────────────────────────────────────────────────────────────
function renderStats(stats) {
  byId("stat-total").textContent   = String(stats.totalEvents   ?? 0);
  byId("stat-blocked").textContent = String(stats.blockedIps    ?? 0);
  byId("stat-high").textContent    = String(stats.highRiskEvents ?? 0);
  byId("stat-recent").textContent  = String(stats.recentEvents  ?? 0);

  const usersEl = byId("stat-users");
  if (usersEl) usersEl.textContent = String(stats.totalUsers ?? 0);

  const alertsStatus = byId("alerts-status");
  if (alertsStatus) {
    alertsStatus.textContent = stats.alertsEnabled ? "Email alerts enabled" : "Email alerts not configured";
    alertsStatus.className   = `chip ${stats.alertsEnabled ? "live" : "warn"}`;
  }
}

// ── Admin — blocked IPs ────────────────────────────────────────────────────────
function renderBlockedIps() {
  const list = byId("blocked-ips-list") || byId("blocked-list");
  if (!list) return;
  clearChildren(list);

  // Push all blocked entries into the map
  if (window.SOC_MAP) window.SOC_MAP.loadEntries(state.blockedIps);

  if (!state.blockedIps.length) {
    const item = document.createElement("div");
    item.className = "empty-state";
    item.textContent = "No IPs currently blocked.";
    list.appendChild(item);
    return;
  }

  state.blockedIps.forEach(({ ip, reason, location, vpnSuspected, isp, org, lat, lon }) => {
    const item = document.createElement("div");
    item.style.cssText = "padding:14px;border-radius:16px;background:var(--surface-strong);border:1px solid var(--border);display:grid;gap:8px;";

    const row1 = document.createElement("div");
    row1.style.cssText = "display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;";

    const ipLabel = document.createElement("span");
    ipLabel.className = "mono";
    ipLabel.textContent = ip;

    const badges = document.createElement("span");
    badges.style.cssText = "display:flex;gap:6px;align-items:center;";
    if (vpnSuspected) {
      const vpnBadge = document.createElement("span");
      vpnBadge.style.cssText = "font-size:0.72rem;font-weight:700;padding:2px 8px;border-radius:999px;background:rgba(167,139,250,0.15);color:#a78bfa;";
      vpnBadge.textContent = "VPN";
      badges.appendChild(vpnBadge);
    }
    const btn = document.createElement("button");
    btn.className = "danger";
    btn.style.padding = "6px 12px";
    btn.textContent = "Unblock";
    btn.addEventListener("click", () => unblockIp(ip, btn));
    badges.appendChild(btn);

    row1.append(ipLabel, badges);

    const locLine = document.createElement("div");
    locLine.style.cssText = "font-size:0.82rem;color:var(--muted);line-height:1.5;";
    locLine.textContent = [location, isp, org].filter(Boolean).join(" · ") || "Unknown location";

    // Clicking the card flies the map to that pin
    const flyBtn = document.createElement("button");
    flyBtn.style.cssText = "font-size:0.78rem;padding:5px 12px;width:fit-content;";
    flyBtn.textContent = "📍 Show on map";
    flyBtn.addEventListener("click", () => window.SOC_MAP?.flyTo(ip));

    item.append(row1, locLine, flyBtn);
    list.appendChild(item);
  });
}

// ── Leaflet SOC_MAP ────────────────────────────────────────────────────────────
function initLeafletMap() {
  const mapEl = document.getElementById("leaflet-map");
  if (!mapEl || !window.L) return;

  // Dark-themed CartoDB tiles (looks great, free, no API key)
  const map = L.map("leaflet-map", {
    center: [20, 10],
    zoom: 2,
    minZoom: 1,
    maxZoom: 18,
    zoomControl: true,
    attributionControl: true
  });

  L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png", {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
    subdomains: "abcd",
    maxZoom: 20
  }).addTo(map);

  // Custom red pulsing icon
  const blockedIcon = L.divIcon({
    className: "",
    html: `<div style="
      width:18px;height:18px;border-radius:50%;
      background:rgba(255,122,89,0.9);
      border:2px solid #fff;
      box-shadow:0 0 0 4px rgba(255,122,89,0.35),0 0 18px rgba(255,122,89,0.7);
    "></div>`,
    iconSize: [18, 18],
    iconAnchor: [9, 9],
    popupAnchor: [0, -12]
  });

  const markers = new Map(); // ip → L.Marker

  const emptyOverlay = document.getElementById("blocked-map-empty");

  function showEmpty(show) {
    if (!emptyOverlay) return;
    emptyOverlay.classList.toggle("hidden", !show);
  }

  function loadEntries(entries) {
    // Remove markers no longer in the list
    const currentIps = new Set(entries.map(e => e.ip));
    markers.forEach((marker, ip) => {
      if (!currentIps.has(ip)) { marker.remove(); markers.delete(ip); }
    });

    const validEntries = entries.filter(e => e.lat && e.lon && Math.abs(e.lat) <= 90 && Math.abs(e.lon) <= 180);
    showEmpty(validEntries.length === 0);

    validEntries.forEach(entry => {
      const { ip, lat, lon, location, risk, vpnSuspected, isp, org, reason } = entry;

      if (markers.has(ip)) {
        // Update popup content in case risk changed
        markers.get(ip).getPopup()?.setContent(buildPopup(entry));
        return;
      }

      const marker = L.marker([lat, lon], { icon: blockedIcon })
        .addTo(map)
        .bindPopup(buildPopup(entry), { maxWidth: 280 });

      markers.set(ip, marker);
    });

    // Update summary text
    const summaryEl = document.getElementById("blocked-map-summary");
    if (summaryEl) {
      summaryEl.textContent = validEntries.length
        ? `${validEntries.length} blocked source${validEntries.length > 1 ? "s" : ""} mapped live.`
        : "Blocked sources with coordinates appear here as live pins.";
    }
  }

  function buildPopup(entry) {
    const { ip, location, risk, vpnSuspected, isp, org, reason } = entry;
    const riskClass = ["high", "critical"].includes(String(risk || "").toLowerCase())
      ? `soc-risk-${String(risk).toLowerCase()}` : "";
    const provider = [isp, org].filter(Boolean).join(" / ");
    return `<div class="soc-popup">
      <strong>${ip}</strong>
      <div>${location || "Unknown location"}</div>
      ${provider ? `<div style="color:#666;font-size:0.82rem;">${provider}</div>` : ""}
      ${risk ? `<div class="${riskClass}" style="margin-top:4px;">Risk: ${risk}</div>` : ""}
      ${vpnSuspected ? `<div class="soc-vpn">⚠ VPN / Proxy suspected</div>` : ""}
      ${reason ? `<div style="margin-top:6px;font-size:0.82rem;color:#555;">${reason}</div>` : ""}
    </div>`;
  }

  function flyTo(ip) {
    const marker = markers.get(ip);
    if (!marker) return;
    map.flyTo(marker.getLatLng(), 6, { animate: true, duration: 1.2 });
    marker.openPopup();
  }

  window.SOC_MAP = { loadEntries, flyTo, map };
}

// ── Admin — timeline / logs ────────────────────────────────────────────────────
function addEmptyTimelineMessage(message) {
  const timeline = byId("timeline");
  if (!timeline) return;
  clearChildren(timeline);
  const item = document.createElement("li");
  item.className = "empty-state";
  item.textContent = message;
  timeline.appendChild(item);
}

function renderLogs() {
  const timeline = byId("timeline");
  if (!timeline) return;

  const filter = byId("risk-filter")?.value || "all";
  const filtered = filter === "all"
    ? state.logs
    : state.logs.filter(l => String(l.risk || "").toLowerCase() === filter);

  clearChildren(timeline);

  if (!filtered.length) {
    addEmptyTimelineMessage("No events match the selected filter.");
    return;
  }

  filtered.forEach(entry => {
    const item = document.createElement("li");
    item.className = "timeline-item";

    const risk = String(entry.risk || "low").toLowerCase();
    const pill = makeBadge(toTitleCase(risk), `risk-pill ${risk}`);

    const meta = document.createElement("div");
    meta.className = "timeline-meta";

    const time = document.createElement("span");
    time.className = "timeline-time";
    time.textContent = formatDateTime(entry.timestamp);

    const ip = document.createElement("span");
    ip.className = "mono";
    ip.textContent = entry.ip || "Unknown IP";

    const loc = document.createElement("span");
    loc.textContent = formatLocationLabel(entry);

    const user = document.createElement("span");
    user.textContent = entry.username ? `User: ${entry.username}` : "Unknown user";

    meta.append(time, ip, loc, user);

    const reason = document.createElement("div");
    reason.className = "timeline-reason";
    reason.textContent = entry.reason || "No reason provided.";

    item.append(pill, meta, reason);
    timeline.appendChild(item);
  });
}

// ── Admin — replay ─────────────────────────────────────────────────────────────
function clearReplayTimer() {
  if (state.replayTimer) {
    clearInterval(state.replayTimer);
    state.replayTimer = null;
  }
}

async function replayTimeline() {
  const button = byId("replay-button");
  clearReplayTimer();

  const logs = await request("/logs");
  const all  = Array.isArray(logs) ? [...logs].reverse() : [];

  if (!all.length) {
    addEmptyTimelineMessage("No events to replay.");
    return;
  }

  setButtonLoading(button, true, "Replaying…");
  const timeline = byId("timeline");
  if (timeline) clearChildren(timeline);
  state.logs = [];

  let index = 0;
  state.replayTimer = setInterval(() => {
    if (index >= all.length) {
      clearReplayTimer();
      setButtonLoading(button, false);
      return;
    }
    state.logs.unshift(all[index]);
    renderLogs();
    index++;
  }, 600);

  try {
    await new Promise(resolve => {
      const check = setInterval(() => {
        if (!state.replayTimer) { clearInterval(check); resolve(); }
      }, 100);
    });
  } finally {
    if (!state.replayTimer) setButtonLoading(button, false);
  }
}

// ── Admin — load helpers ───────────────────────────────────────────────────────
async function loadLogs() {
  const logs  = await request("/logs");
  state.logs  = Array.isArray(logs) ? logs : [];
  renderLogs();
}

async function loadStats() {
  const stats = await request("/stats");
  renderStats(stats);
}

async function loadBlockedIps() {
  const blockedIps = await request("/blocked-ips");
  state.blockedIps = Array.isArray(blockedIps) ? blockedIps : [];
  renderBlockedIps();
}

async function loadDashboard() {
  await Promise.all([loadLogs(), loadStats(), loadBlockedIps(), loadUsers()]);
  if (!state.logs.length) {
    addEmptyTimelineMessage("No events yet. Use Simulate Attack or try logging in.");
  }
}

async function simulateAttack() {
  const button = byId("simulate-button");
  setButtonLoading(button, true, "Simulating...");
  try {
    await request("/simulate?count=6");
    await loadDashboard();
  } catch (error) {
    addEmptyTimelineMessage(error.message);
  } finally {
    setButtonLoading(button, false);
  }
}

async function unblockIp(ip, button) {
  if (!confirm(`Unblock IP "${ip}"?`)) return;
  setButtonLoading(button, true, "Unblocking...");
  try {
    await request(`/blocked-ips/${encodeURIComponent(ip)}/unblock`, { method: "POST" });
    await Promise.all([loadBlockedIps(), loadStats(), loadLogs()]);
  } finally {
    setButtonLoading(button, false);
  }
}

// ── Admin — user management ────────────────────────────────────────────────────
function setUserFeedback(message, isError = false) {
  const el = byId("user-feedback");
  if (!el) return;
  el.textContent = message;
  el.className   = isError ? "error" : "";
}

async function loadUsers() {
  try {
    const users = await request("/users");
    renderUsers(users);
  } catch (error) {
    setUserFeedback(error.message, true);
  }
}

function renderUsers(users) {
  const tbody = byId("users-body");
  if (!tbody) return;
  clearChildren(tbody);

  if (!users.length) {
    const row  = document.createElement("tr");
    const cell = document.createElement("td");
    cell.colSpan    = 4;
    cell.className  = "empty-state";
    cell.textContent = "No users found.";
    row.appendChild(cell);
    tbody.appendChild(row);
    return;
  }

  users.forEach((user) => {
    const row = document.createElement("tr");

    const tdName = document.createElement("td");
    tdName.className   = "mono";
    tdName.textContent = user.username;

    const tdRole = document.createElement("td");
    tdRole.appendChild(makeBadge(toTitleCase(user.role || "user"), `role-pill ${user.role || "user"}`));

    const tdCreated = document.createElement("td");
    tdCreated.textContent = formatDateTime(user.createdAt);

    const tdAction = document.createElement("td");
    if (user.username !== "admin") {
      const btn = document.createElement("button");
      btn.className   = "danger";
      btn.textContent = "Delete";
      btn.style.padding = "8px 14px";
      btn.addEventListener("click", () => deleteUser(user.username));
      tdAction.appendChild(btn);
    } else {
      tdAction.textContent = "—";
      tdAction.style.color = "var(--muted)";
    }

    row.append(tdName, tdRole, tdCreated, tdAction);
    tbody.appendChild(row);
  });
}

async function createUser() {
  const button   = byId("create-user-button");
  const username = byId("new-username").value.trim();
  const password = byId("new-password").value;
  const email    = byId("new-email").value.trim();
  const role     = byId("new-role").value;

  if (!username || !password) {
    setUserFeedback("Username and password are required.", true);
    return;
  }
  if (!email) {
    setUserFeedback("Email required", true);
    return;
  }

  setButtonLoading(button, true, "Adding...");
  setUserFeedback("");

  try {
    const result = await request("/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password, email, role })
    });
    setUserFeedback(`User "${result.username}" created successfully.`);
    byId("new-username").value = "";
    byId("new-password").value = "";
    byId("new-email").value    = "";
    await loadUsers();
    await loadStats();
  } catch (error) {
    setUserFeedback(error.message, true);
  } finally {
    setButtonLoading(button, false);
  }
}

async function deleteUser(username) {
  if (!confirm(`Delete user "${username}"? This cannot be undone.`)) return;
  setUserFeedback("");
  try {
    await request(`/users/${encodeURIComponent(username)}`, { method: "DELETE" });
    setUserFeedback(`User "${username}" deleted.`);
    await loadUsers();
    await loadStats();
  } catch (error) {
    setUserFeedback(error.message, true);
  }
}

// ── Admin — socket ─────────────────────────────────────────────────────────────
function updateSocketStatus(text, mode) {
  const node = byId("socket-status");
  if (!node) return;
  node.textContent = text;
  node.className   = `chip ${mode}`;
}

function initSocket() {
  if (typeof window.io !== "function") {
    updateSocketStatus("Socket unavailable", "offline");
    return;
  }

  const socket = window.io(API, { transports: ["websocket", "polling"] });

  socket.on("connect",       () => updateSocketStatus("Socket connected",    "live"));
  socket.on("disconnect",    () => updateSocketStatus("Socket disconnected", "offline"));
  socket.on("connect_error", () => updateSocketStatus("Socket degraded",     "warn"));

  socket.on("attack", (log) => {
    state.logs.unshift(log);
    state.logs = state.logs.slice(0, 250);
    renderLogs();
  });

  socket.on("login", (log) => {
    state.logs.unshift(log);
    state.logs = state.logs.slice(0, 250);
    renderLogs();
  });

  socket.on("stats", (stats) => {
    renderStats(stats);
  });

  socket.on("blocked-ips", (blockedIps) => {
    state.blockedIps = Array.isArray(blockedIps) ? blockedIps : [];
    renderBlockedIps();
  });
}

// ── Admin — init ───────────────────────────────────────────────────────────────
function initAdminPage() {
  initLeafletMap();

  byId("risk-filter").addEventListener("change", renderLogs);

  byId("refresh-button").addEventListener("click", () => {
    loadDashboard().catch((e) => addEmptyTimelineMessage(e.message));
  });

  byId("simulate-button").addEventListener("click", () => {
    simulateAttack().catch((e) => addEmptyTimelineMessage(e.message));
  });

  byId("replay-button").addEventListener("click", () => {
    replayTimeline().catch((e) => addEmptyTimelineMessage(e.message));
  });

  byId("clear-timeline-button").addEventListener("click", () => {
    clearReplayTimer();
    addEmptyTimelineMessage("Timeline cleared. Run Replay to rebuild the event sequence.");
  });

  byId("create-user-button").addEventListener("click", () => {
    createUser().catch((e) => setUserFeedback(e.message, true));
  });

  initSocket();
  loadDashboard().catch((e) => addEmptyTimelineMessage(e.message));
}

// ── Bootstrap ──────────────────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  if (PAGE === "admin") {
    initAdminPage();
  } else {
    initLoginPage();
  }
});