#include<stdio.h>
int main() {
    int a = 10;
    int *p = &a;
    printf("%d %d %d", *p, *p++, *p);
    return 0;
}
